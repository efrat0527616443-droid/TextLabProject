import { useState } from 'react'
import FilesList from './FilesList/FilesList'
import './FileManager.css'

{/* הגדרות ערכי ברירת מחדל לכל קובץ בסיסי */ }
// const defaultFile = {
//     id: Date.now(),
//     name: "Untitled",
//     text: "",
//     styles: [
//         {
//             start: 0,
//             end: 1,
//             style: {
//                 fontSize: "16px",
//                 fontFamily: "Arial",
//                 color: "#000000",
//                 backgroundColor: "#ffffff",
//                 direction: "ltr",
//             }
//         }
//     ],
//     Highlights: [],
//     historyMaxLength: 20,
//     history: []
// };

const FileManager = ({ userID, activeFiles, currentFile, newFile, closeFile, openFile }) => {

    const users = JSON.parse(localStorage.getItem("users")) || [];
    const currentUserData = users.find(u => u.id === userID);
    const [savedFiles, setSavedFiles] = useState(currentUserData ? currentUserData.files : []);

    {/* עידכון מערך הקבצים המעודכן */ }
    const updateFilesInLS = (callbacke) => {
        const users = JSON.parse(localStorage.getItem("users")) || [];
        const index = users.findIndex(u => u.id === userID);
        if (index !== -1) {
            users[index].files = callbacke(users[index].files);
        }
         localStorage.setItem("users", JSON.stringify(users));
    }


    // לבדוק ----------------------------
    {/* מיזוג סגנונות סמוכים זהים */ }
    function mergeAdjacentStyles() {
        let styles = activeFiles[currentFile].styles;
        if (!styles || styles.length === 0) return [];

        // קודם כל נמיין לפי התחלה
        const sorted = [...styles].sort((a, b) => a.start - b.start);

        const merged = [sorted[0]];

        for (let i = 1; i < sorted.length; i++) {
            const prev = merged[merged.length - 1];
            const curr = sorted[i];

            // נבדוק אם הם רצופים ובעלי אותו style
            const areAdjacent = prev.end === curr.start;
            const haveSameStyle = JSON.stringify(prev.style) === JSON.stringify(curr.style);

            if (areAdjacent && haveSameStyle) {
                // נעדכן את הסוף של הקודם במקום להוסיף חדש
                prev.end = curr.end;
            } else {
                merged.push(curr);
            }
        }

        return merged;
    }


    {/* שמירת קובץ */ }
    const save = (type) => {
        mergeAdjacentStyles();
        updateFilesInLS((files) => {
            const fileID = activeFiles[currentFile].id;
            const index = files.findIndex(file => file.id === fileID);

            /* שמירת קובץ חדש */
            if (index === -1) {
                if (type === 'saveAs') {
                    const fileName = prompt("Enter a file name: ", activeFiles[currentFile].name);
                    activeFiles[currentFile].name = fileName ? fileName : "Untitled";
                }
                files.push(activeFiles[currentFile])
            }
            /* שמירת קובץ קיים */
            else {
                if (type === 'saveAs') {
                    const fileName = prompt("Enter a file name: ", activeFiles[currentFile].name);
                    activeFiles[currentFile].name = fileName ? fileName : "Untitled";
                }
                files[index] = activeFiles[currentFile];
            }
            return [...files];
        })
        alert('The file was saved successfully! 👍')
        updateSavesFiles();
    }


    {/* סגירת קובץ */ }
    const close = () => {
        const toSave = confirm('Would you like to save the changes?');
        // toSave ? save('save') : null;
        if (toSave) {
            activeFiles[currentFile].history = [];
            save('save');
        }
        closeFile();
    }


    {/* עדכון רשימת הקבצים */ }
    const updateSavesFiles = () => {
        const exists = savedFiles.some(file => file.id === activeFiles[currentFile].id);
        { !exists && setTimeout(() => setSavedFiles([...savedFiles, activeFiles[currentFile]]), 0); }
    }


    return (

        <div className='FileManagerContainer'>
            <div className='FileManagerButtons'>
                <button onClick={newFile}>New File</button>
                {/* <button>Open</button> */}
                {currentFile !== -1 && <button onClick={close}>Close</button>}
                {currentFile !== -1 && <button onClick={() => save('save')}>Save</button>}
                {currentFile !== -1 && <button onClick={() => save('saveAs')}>Save as</button>}
            </div>

            <FilesList
                openFile={(file) => openFile(file)}
                savedFiles={savedFiles}
            />
        </div>
    )
}

export default FileManager